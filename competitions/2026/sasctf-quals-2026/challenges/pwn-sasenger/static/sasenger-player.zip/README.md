# Sasenger

A local replica of the Sasenger target: the relay plus two Android devices (attacker + victim), app installed and logged in. Use it to debug the app and develop your exploit, then point it at the remote instance you were issued.

our only channel to the victim is the messaging system; the goal is code execution to read the flag from the device.

## Requirements

- ~4 GB RAM + 2 vCPUs per device, ~8 GB disk for the Android images.

## Run

```sh
./setup.sh        # one-time: build images + download the device images (~4 GB)
./run.sh up       # relay + 2 devices, app installed and logged in
```

After `up`:

- victim - adb `127.0.0.1:6521`, account `@victim` (polls, auto-processes inbound)
- attacker - adb `127.0.0.1:6520`, account `@attacker`
- relay - `http://127.0.0.1:8080`

## Commands

```
./run.sh up                 # bring everything up
./run.sh send [text]        # attacker -> victim: a text message
./run.sh send-raw <file>    # attacker -> victim: raw bytes as the message payload
./run.sh ui [victim|attacker]      # scrcpy window(s); no arg = both
./run.sh shell [victim|attacker]   # adb shell
./run.sh logcat [victim|attacker]  # app log (tag Sasenger)
./run.sh gdb [victim|attacker]     # attach gdbserver, emit a gdb script
./run.sh sysroot            # rebuild the local device-lib cache for gdb
./run.sh down               # tear down
```

## Debugging

`./run.sh gdb victim` pushes a gdbserver, attaches, and prints a
`pwndbg -x /tmp/sas-gdb-victim.gdb` line. The script uses a local sysroot for the
system/ART libs; load any other module's symbols on demand with `sharedlibrary`.

gdb needs a gdbserver matching its version. If the harness can't find one, build
it with `scripts/build_gdbserver.sh` (-> `/tmp/sas-gdbserver`) or set `GDBSERVER=`.

## Env

| var | default | meaning |
|---|---|---|
| `CF_CPUS` / `CF_MEM_MB` | 2 / 2048 | per-device sizing |
| `RELAY_GUEST_HOST` | 192.168.97.1 | host IP the guest uses to reach the relay |
| `GDBSERVER` | - | path to a gdbserver matching your gdb |
| `DBG_PORT` | 5039 | gdbserver port |
| `CF_BUILD` / `CF_TARGET` | see `setup.sh` | AOSP device build to fetch (pinned by default) |

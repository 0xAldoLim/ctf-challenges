#!/usr/bin/env bash
#   ./setup.sh                # build cf-host + relay images, then fetch device images
#   ./setup.sh images         # (re)fetch only the device images
#   ./setup.sh images-clean   # delete the fetched images and re-fetch
set -euo pipefail

PKG="$(cd "$(dirname "$0")" && pwd)"
IMAGES_DIR="$PKG/images"
CF_BUILD="${CF_BUILD:-15357239}"
CF_TARGET="${CF_TARGET:-aosp_cf_x86_64_only_phone-userdebug}"

log() { echo "[setup] $*"; }

need() { command -v "$1" >/dev/null 2>&1 || { echo "[setup] ERROR: '$1' is required but not installed"; exit 1; }; }

build_images() {
    need docker
    log "building cf-host:sas (Cuttlefish host: Debian + prebuilt cuttlefish packages)"
    docker build -t cf-host:sas "$PKG/docker/cf-host"

    log "building sasenger-relay"
    docker build -t sasenger-relay "$PKG/docker/relay"
}

fetch_images() {
    need docker
    docker image inspect cf-host:sas >/dev/null 2>&1 || {
        echo "[setup] cf-host:sas image missing — run './setup.sh' (no args) first"; exit 1; }
    if [ -f "$IMAGES_DIR/super.img" ]; then
        log "device images already present in ./images (delete them or run './setup.sh images-clean' to re-fetch)"
        return 0
    fi
    mkdir -p "$IMAGES_DIR"
    log "downloading $CF_BUILD/$CF_TARGET into ./images (~6 GB, one-time)…"
    docker run --rm -v "$IMAGES_DIR:/cf/images" cf-host:sas \
        cvd fetch --target_directory=/cf/images --default_build="$CF_BUILD/$CF_TARGET"
    log "device images ready in ./images"
}

case "${1:-all}" in
    all)          build_images; fetch_images ;;
    images)       fetch_images ;;
    images-clean) rm -rf "$IMAGES_DIR"; fetch_images ;;
    *) echo "usage: $0 {all|images|images-clean}"; exit 1 ;;
esac

cat <<EOF

[setup] done. Next:
  ./run.sh up      # boot 2 local devices + relay, install the app, auto-login
  ./run.sh         # (no args) prints the full command list
EOF
